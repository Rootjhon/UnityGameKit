import os
lines = open('TempWorkSpace/AndroidManifest.xml').readlines()
fp = open('TempWorkSpace/AndroidManifest.xml','w+')
for s in lines:
    fp.write(s.replace('android.intent.action.MAIN','com.qqgame.happymj').replace('android.intent.category.LAUNCHER','android.intent.category.DEFAULT'))    
fp.close()